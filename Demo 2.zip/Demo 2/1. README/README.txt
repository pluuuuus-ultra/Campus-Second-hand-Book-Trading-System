��Importing war file into Eclipse JEE
��Loading the project to Tomcat 9.0 server
��Operating items
��The login account number is user111 and the password is 123456.