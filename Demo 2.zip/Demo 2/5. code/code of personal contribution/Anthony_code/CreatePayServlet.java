package com.gyf.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.gyf.bookstore.service.OrderService;

/**
 * Servlet implementation class DeleteOrderServlet
 */
@WebServlet("/createpay")
public class CreatePayServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String orderid=request.getParameter("orderid");
		System.out.println(orderid);
		OrderService os = new OrderService();
		os.createpay(orderid);
		request.getRequestDispatcher("/paysuccess.jsp").forward(request, response);
		} 
}
