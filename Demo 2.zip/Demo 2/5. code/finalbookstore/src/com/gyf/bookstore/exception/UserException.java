package com.gyf.bookstore.exception;

public class UserException extends Exception{

	public UserException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
