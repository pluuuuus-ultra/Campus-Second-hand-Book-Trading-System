create database bookstore;
use bookstore
CREATE TABLE `user` (
  `id` INT(11) AUTO_INCREMENT,
  `username` VARCHAR(20) ,
  `PASSWORD` VARCHAR(20) ,
  `gender` VARCHAR(10) ,
  `email` VARCHAR(50) ,
  `telephone` VARCHAR(20) ,
  `introduce` VARCHAR(100),
  `activeCode` VARCHAR(50) ,
  `state` INT(11) ,
  `role` VARCHAR(10) DEFAULT 'user',
  `registTime` TIMESTAMP ,
  PRIMARY KEY (`id`)
)
CREATE TABLE `products` (
  `id` VARCHAR(100) ,
  `name` VARCHAR(40) ,
  `price` DOUBLE ,
  `category` VARCHAR(40) ,
  `pnum` INT(11) ,
  `imgurl` VARCHAR(100) ,
  `description` VARCHAR(255) ,
  PRIMARY KEY (`id`)
)
CREATE TABLE `orders` (
  `id` VARCHAR(100) ,
  `money` DOUBLE ,
  `receiverAddress` VARCHAR(255) ,
  `receiverName` VARCHAR(20) ,
  `receiverPhone` VARCHAR(20) ,
  `paystate` INT(11) ,
  `ordertime` TIMESTAMP ,
  `user_id` INT(11) ,
  PRIMARY KEY (`id`)
)
CREATE TABLE `orderitem` (
  `order_id` VARCHAR(100) ,
  `product_id` VARCHAR(100),
  `buynum` INT(11) ,
  PRIMARY KEY (`order_id`,`product_id`)
)
CREATE TABLE `sell` (
  `id` VARCHAR(100) ,
  `user_id` INT(11),
 `sellBook` VARCHAR(20) ,
  `sellAddress` VARCHAR(255) ,
  `sellName` VARCHAR(20) ,
  `sellPhone` VARCHAR(20) ,
  PRIMARY KEY (`id`)
)
insert into user value (1,"user","123456",null,null,null,null,null,1,"user",null);
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (1,'Java',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (2,'HTML',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (3,'JS',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (4,'PHP',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (5,'Android',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (6,'iOSF',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (7,'MySQL',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (8,'Oracle',168.88,'computer',3,null,'good book');
INSERT INTO products (id,name,price,category,pnum,imgurl,description) 
VALUES (9,'VMWare',168.88,'computer',3,null,'good book');